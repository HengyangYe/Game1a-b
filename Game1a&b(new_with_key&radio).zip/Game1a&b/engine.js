class Engine {

    static load(...args) {
        window.onload = () => new Engine(...args);
    }

    constructor(firstSceneClass, storyDataUrl) {
        this.inventory = [];
        this.firstSceneClass = firstSceneClass;
        this.storyDataUrl = storyDataUrl;

        this.header = document.body.appendChild(document.createElement("h1"));
        this.output = document.body.appendChild(document.createElement("div"));
        this.actionsContainer = document.body.appendChild(document.createElement("div"));

        this.load();
    }

    load() {
        fetch(this.storyDataUrl).then(
            response => response.json()
        ).then(
            json => {
                this.storyData = json;
                this.gotoScene(this.firstSceneClass);
            }
        ).catch(error => {
            console.error('Failed to load story data:', error);
            this.show('Error loading the game. Please check the console for details.');
        });
    }

    addItem(itemName) {
        this.inventory.push(itemName);
        this.show("You have obtained: " + itemName);
    }

    hasItem(itemName) {
        return this.inventory.includes(itemName);
    }

    gotoScene(sceneClass, data) {
        this.scene = new sceneClass(this);
        this.scene.create(data);
    }

    addChoice(action, data, requiredItem = null, awardItem = null) {
        let button = this.actionsContainer.appendChild(document.createElement("button"));
        button.innerText = action;
        button.onclick = () => {
            if (requiredItem && !this.hasItem(requiredItem)) {
                this.show("You do not have the required item: " + requiredItem);
                return;
            }
            if (awardItem) {
                this.addItem(awardItem);
            }
            while (this.actionsContainer.firstChild) {
                this.actionsContainer.removeChild(this.actionsContainer.firstChild);
            }
            this.scene.handleChoice(data);
        };
    }

    setTitle(title) {
        document.title = title;
        this.header.innerText = title;
    }

    show(msg) {
        let div = document.createElement("div");
        div.innerHTML = msg;
        this.output.appendChild(div);
    }
}

class Scene {
    constructor(engine) {
        this.engine = engine;
    }

    create() { }

    update() { }

    handleChoice(action) {
        console.warn('no choice handler on scene ', this);
    }
}